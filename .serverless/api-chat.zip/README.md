# websockets-node-js-sls
Probando websockets usando aws academy, sls
